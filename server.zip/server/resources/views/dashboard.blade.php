@include("inc/header")

<!-- Begin Page Content -->
<div class="container-fluid">

</div>

<!-- /.container-fluid -->
@include("inc/footer")