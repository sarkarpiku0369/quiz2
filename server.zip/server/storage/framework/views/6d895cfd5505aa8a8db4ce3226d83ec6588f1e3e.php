<?php echo $__env->make("inc/header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Begin Page Content -->
<div class="container-fluid mb-5">

    <div class="row mb-3">
        <div class="col-md-6">
            <h2 class="text-dark">Questions</h2>
        </div>
        <div class="col-md-6">
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success alert-block" style="float: right;">
                    <button type="button" class="close" data-dismiss="alert" style="margin-left: 20px;">×</button>	
                        <strong><?php echo e($message); ?></strong>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Level</th>
                    <th>Question</th>
                    <th>Option 1</th>
                    <th>Option 2</th>
                    <th>Option 3</th>
                    <th>Option 4</th>
                    <th>Correct Option</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($question->level); ?></td>
                        <td><?php echo e($question->question); ?></td>
                        <td><?php echo e($question->option_1); ?></td>
                        <td><?php echo e($question->option_2); ?></td>
                        <td><?php echo e($question->option_3); ?></td>
                        <td><?php echo e($question->option_4); ?></td>
                        <td><?php echo e($question->correct_option); ?></td>
                        <td>
                            <div class="btn-group" role="group">
                                <a href="<?php echo e(url('/question/edit/')); ?><?php echo "/".$question->id?>"  class="btn btn-sm btn-outline-secondary mx-1"><i class="fa fa-pen"></i></a>
                                <a href="<?php echo e(url('/question/delete/')); ?><?php echo "/".$question->id?>"  class="btn btn-sm btn-outline-secondary"><i class="fa fa-trash"></i></a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

</div>

<!-- /.container-fluid -->
<?php echo $__env->make("inc/footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\quizapp\server\resources\views/Question/index.blade.php ENDPATH**/ ?>