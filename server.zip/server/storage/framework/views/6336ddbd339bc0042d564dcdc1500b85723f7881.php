<?php echo $__env->make("inc/header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Begin Page Content -->
<div class="container-fluid mb-5">

    <div class="row mb-3">
        <div class="col-md-6">
            <h2 class="text-dark">Players</h2>
        </div>
        <div class="col-md-6">
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success alert-block" style="float: right;">
                    <button type="button" class="close" data-dismiss="alert" style="margin-left: 20px;">×</button>	
                        <strong><?php echo e($message); ?></strong>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th style="text-align: left;">Player Name</th>
                    <th style="text-align: left;">Email</th>
                    <th style="text-align: left;">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="text-align: left;"><?php echo e($user->name); ?></td>
                        <td style="text-align: left;"><?php echo e($user->email); ?></td>
                        <td style="text-align: left;">
                            <div class="btn-group" role="group">
                                <form action="<?php echo e(route('user.destroy', $user->id)); ?>" method="POST">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-secondary"><i class="fa fa-trash"></i></button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="row justify-content-center">
        <?php echo e($users->links('pagination::bootstrap-4')); ?>

    </div>
</div>

<!-- /.container-fluid -->
<?php echo $__env->make("inc/footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\quiz2\server\resources\views/Player/index.blade.php ENDPATH**/ ?>