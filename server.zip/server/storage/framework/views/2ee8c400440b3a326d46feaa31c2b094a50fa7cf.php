<?php echo $__env->make("inc/header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Begin Page Content -->
<div class="container-fluid">

</div>

<!-- /.container-fluid -->
<?php echo $__env->make("inc/footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\quizapp\server\resources\views/dashboard.blade.php ENDPATH**/ ?>